<?php

$day = $_POST['day'];
$month = $_POST['month'];
$year = $_POST['year'];
echo 'Day '.$day.' Month '.$month.' Year '.$year;


?>